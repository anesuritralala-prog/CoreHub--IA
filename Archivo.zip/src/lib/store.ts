import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: number;
}

export interface Conversation {
  id: string;
  title: string;
  messages: Message[];
  createdAt: number;
  updatedAt: number;
}

export interface Settings {
  apiKey: string;
  apiUrl: string;
  authHeader: string;
}

interface ChatStore {
  conversations: Conversation[];
  currentConversationId: string | null;
  settings: Settings;
  isStreaming: boolean;

  // Actions
  setCurrentConversation: (id: string | null) => void;
  newConversation: () => string;
  deleteConversation: (id: string) => void;
  addMessage: (conversationId: string, message: Omit<Message, 'id' | 'createdAt'>) => Message;
  updateMessage: (conversationId: string, messageId: string, content: string) => void;
  updateSettings: (settings: Partial<Settings>) => void;
  setIsStreaming: (streaming: boolean) => void;
  getCurrentConversation: () => Conversation | undefined;
}

const generateId = (): string => {
  return Date.now().toString(36) + Math.random().toString(36).substring(2);
};

export const useChatStore = create<ChatStore>()(
  persist(
    (set, get) => ({
      conversations: [],
      currentConversationId: null,
      settings: {
        apiKey: 'anesuri.3415.3dd',
        apiUrl: 'http://93.177.64.145:9200/ia/corehub-v1/chat',
        authHeader: 'X-API-Key',
      },
      isStreaming: false,

      setCurrentConversation: (id) => set({ currentConversationId: id }),

      newConversation: () => {
        const id = generateId();
        const now = Date.now();
        const conversation: Conversation = {
          id,
          title: 'Nuevo chat',
          messages: [],
          createdAt: now,
          updatedAt: now,
        };
        set((state) => ({
          conversations: [conversation, ...state.conversations],
          currentConversationId: id,
        }));
        return id;
      },

      deleteConversation: (id) => {
        set((state) => {
          const filtered = state.conversations.filter((c) => c.id !== id);
          const newCurrentId =
            state.currentConversationId === id
              ? filtered[0]?.id ?? null
              : state.currentConversationId;
          return {
            conversations: filtered,
            currentConversationId: newCurrentId,
          };
        });
      },

      addMessage: (conversationId, message) => {
        const now = Date.now();
        const newMessage: Message = {
          ...message,
          id: generateId(),
          createdAt: now,
        };

        set((state) => ({
          conversations: state.conversations.map((c) => {
            if (c.id !== conversationId) return c;
            const updatedMessages = [...c.messages, newMessage];

            // Auto-generate title from first user message
            let title = c.title;
            if (message.role === 'user' && c.messages.length === 0) {
              title = message.content.slice(0, 50) + (message.content.length > 50 ? '...' : '');
            }

            return {
              ...c,
              title,
              messages: updatedMessages,
              updatedAt: now,
            };
          }),
        }));

        return newMessage;
      },

      updateMessage: (conversationId, messageId, content) => {
        set((state) => ({
          conversations: state.conversations.map((c) => {
            if (c.id !== conversationId) return c;
            return {
              ...c,
              messages: c.messages.map((m) =>
                m.id === messageId ? { ...m, content } : m
              ),
              updatedAt: Date.now(),
            };
          }),
        }));
      },

      updateSettings: (newSettings) => {
        set((state) => ({
          settings: { ...state.settings, ...newSettings },
        }));
      },

      setIsStreaming: (streaming) => set({ isStreaming: streaming }),

      getCurrentConversation: () => {
        const state = get();
        return state.conversations.find(
          (c) => c.id === state.currentConversationId
        );
      },
    }),
    {
      name: 'chatgpt-clone-storage',
      partialize: (state) => ({
        conversations: state.conversations,
        currentConversationId: state.currentConversationId,
        settings: state.settings,
      }),
    }
  )
);
