'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { useChatStore } from '@/lib/store';
import Sidebar from '@/components/chat/sidebar';
import ChatArea from '@/components/chat/chat-area';
import ChatInput from '@/components/chat/chat-input';
import SettingsDialog from '@/components/chat/settings-dialog';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Menu, Sparkles } from 'lucide-react';
import { Toaster, toast } from 'sonner';

function buildPrompt(messages: { role: string; content: string }[]): string {
  if (messages.length === 0) return '';
  if (messages.length === 1) return messages[0].content;

  let context = '';
  for (let i = 0; i < messages.length - 1; i++) {
    const msg = messages[i];
    const role = msg.role === 'user' ? 'Usuario' : 'Asistente';
    context += `${role}: ${msg.content}\n\n`;
  }

  const lastMessage = messages[messages.length - 1].content;
  return `${context}Responde como asistente al siguiente mensaje del usuario:\nUsuario: ${lastMessage}`;
}

export default function Home() {
  const {
    currentConversationId, settings, isStreaming,
    setIsStreaming, addMessage, updateMessage, newConversation,
  } = useChatStore();

  const [settingsOpen, setSettingsOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    if (!settings.apiKey) {
      const timer = setTimeout(() => setSettingsOpen(true), 500);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleNewChat = useCallback(() => {
    newConversation();
    setSidebarOpen(false);
  }, [newConversation]);

  const handleSendMessage = useCallback(async (content: string) => {
    if (!settings.apiKey || !settings.apiUrl) {
      setSettingsOpen(true);
      toast.error('Configura tu API key y URL en Ajustes.');
      return;
    }

    let convId = currentConversationId;
    if (!convId) convId = newConversation();

    addMessage(convId, { role: 'user', content });
    const assistantMessage = addMessage(convId, { role: 'assistant', content: '...' });
    setIsStreaming(true);

    try {
      const conversation = useChatStore.getState().conversations.find((c) => c.id === convId);
      const allMessages = (conversation?.messages || [])
        .filter((m) => m.id !== assistantMessage.id)
        .map((m) => ({ role: m.role, content: m.content }));

      const prompt = buildPrompt(allMessages);

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt,
          apiKey: settings.apiKey,
          apiUrl: settings.apiUrl,
          authHeader: settings.authHeader,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ error: 'Error desconocido' }));
        updateMessage(convId!, assistantMessage.id, `Error: ${errorData.error || 'No se pudo conectar.'}`);
        setIsStreaming(false);
        return;
      }

      const data = await response.json();

      if (data.error) {
        updateMessage(convId!, assistantMessage.id, `Error: ${data.error}`);
      } else if (data.reply) {
        updateMessage(convId!, assistantMessage.id, data.reply);
      } else {
        updateMessage(convId!, assistantMessage.id, 'La API no devolvió una respuesta válida.');
      }
    } catch (error) {
      console.error('Chat error:', error);
      updateMessage(convId!, assistantMessage.id, 'Error: No se pudo conectar con la API.');
    } finally {
      setIsStreaming(false);
    }
  }, [currentConversationId, settings, isStreaming, addMessage, updateMessage, newConversation, setIsStreaming]);

  return (
    <div className="flex h-screen bg-[#212121]">
      <Toaster position="top-center" richColors theme="dark" toastOptions={{
        style: { background: '#2f2f2f', border: '1px solid rgba(255,255,255,0.1)', color: '#ececec' },
      }} />

      {/* Desktop Sidebar */}
      <div className="hidden md:flex w-[260px] flex-shrink-0">
        <Sidebar onNewChat={handleNewChat} onOpenSettings={() => setSettingsOpen(true)} />
      </div>

      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="p-0 w-[280px] bg-[#171717] border-white/10">
          <SheetTitle className="sr-only">Menú</SheetTitle>
          <Sidebar onNewChat={handleNewChat} onOpenSettings={() => { setSettingsOpen(true); setSidebarOpen(false); }} />
        </SheetContent>
      </Sheet>

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="flex items-center gap-3 px-4 py-3 border-b border-white/5 flex-shrink-0">
          <Button variant="ghost" size="icon" className="md:hidden text-gray-300 hover:bg-white/10"
            onClick={() => setSidebarOpen(true)}>
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#10a37f]" />
            <h1 className="text-sm font-semibold text-[#ececec]">ChatAI</h1>
            <span className="hidden sm:inline text-xs text-gray-500 ml-1">CoreHubAI</span>
          </div>
        </header>
        <ChatArea onSendMessage={handleSendMessage} />
        <ChatInput onSend={handleSendMessage} />
      </div>

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
    </div>
  );
}
