import { NextRequest } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { prompt, apiKey, apiUrl, authHeader } = await req.json();

    if (!apiKey) {
      return new Response(
        JSON.stringify({ error: 'Se requiere una API key. Configúrala en Ajustes.' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    if (!apiUrl) {
      return new Response(
        JSON.stringify({ error: 'Se requiere una URL de API. Configúrala en Ajustes.' }),
        { status: 400, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    // Support different auth header formats
    const headerName = (authHeader || 'X-API-Key').trim();
    if (headerName.toLowerCase() === 'bearer' || headerName.toLowerCase() === 'authorization') {
      headers['Authorization'] = `Bearer ${apiKey}`;
    } else {
      headers[headerName] = apiKey;
    }

    const response = await fetch(apiUrl, {
      method: 'POST',
      headers,
      body: JSON.stringify({ prompt }),
    });

    if (!response.ok) {
      const errorBody = await response.text();
      let errorMessage = `Error ${response.status}: No se pudo conectar con la API.`;
      try {
        const parsed = JSON.parse(errorBody);
        errorMessage = parsed.error || parsed.message || errorMessage;
      } catch {
        // use default error
      }
      return new Response(
        JSON.stringify({ error: errorMessage }),
        { status: response.status, headers: { 'Content-Type': 'application/json' } }
      );
    }

    const data = await response.json();

    // Handle CoreHubAI format: { success: boolean, response: string }
    let reply = '';
    if (data.success !== undefined) {
      reply = data.success ? (data.response || data.message || '') : (data.error || 'La API devolvió un error.');
    } else if (data.response) {
      reply = data.response;
    } else if (data.choices?.[0]?.message?.content) {
      // OpenAI-compatible fallback
      reply = data.choices[0].message.content;
    } else if (data.content) {
      reply = data.content;
    } else {
      reply = JSON.stringify(data);
    }

    return new Response(
      JSON.stringify({ reply }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Chat API error:', error);
    return new Response(
      JSON.stringify({ error: 'Error interno del servidor. Verifica tu conexión y configuración.' }),
      { status: 500, headers: { 'Content-Type': 'application/json' } }
    );
  }
}
