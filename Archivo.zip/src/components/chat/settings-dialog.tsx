'use client';

import { useState } from 'react';
import { useChatStore } from '@/lib/store';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Eye, EyeOff, Save } from 'lucide-react';

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { settings, updateSettings } = useChatStore();
  const [showApiKey, setShowApiKey] = useState(false);
  const [localApiKey, setLocalApiKey] = useState(settings.apiKey);
  const [localApiUrl, setLocalApiUrl] = useState(settings.apiUrl);
  const [localAuthHeader, setLocalAuthHeader] = useState(settings.authHeader);

  // Sync local state when dialog opens
  const handleOpen = (isOpen: boolean) => {
    if (isOpen) {
      setLocalApiKey(settings.apiKey);
      setLocalApiUrl(settings.apiUrl);
      setLocalAuthHeader(settings.authHeader);
    }
    onOpenChange(isOpen);
  };

  const handleSave = () => {
    updateSettings({
      apiKey: localApiKey.trim(),
      apiUrl: localApiUrl.trim(),
      authHeader: localAuthHeader.trim() || 'X-API-Key',
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpen}>
      <DialogContent className="bg-[#2f2f2f] border-white/10 text-[#ececec] max-w-md">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-white">Ajustes</DialogTitle>
          <DialogDescription className="text-gray-400">
            Configura tu API de CoreHubAI.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* API Key */}
          <div className="space-y-2">
            <Label htmlFor="apiKey" className="text-sm text-gray-300">
              API Key
            </Label>
            <div className="relative">
              <Input
                id="apiKey"
                type={showApiKey ? 'text' : 'password'}
                value={localApiKey}
                onChange={(e) => setLocalApiKey(e.target.value)}
                placeholder="Tu API Key"
                className="bg-[#1a1a1a] border-white/10 text-[#ececec] placeholder-gray-500 pr-10"
              />
              <button
                onClick={() => setShowApiKey(!showApiKey)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-300"
                type="button"
              >
                {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
            <p className="text-xs text-gray-500">
              Tu API key se guarda localmente en tu navegador.
            </p>
          </div>

          {/* API URL */}
          <div className="space-y-2">
            <Label htmlFor="apiUrl" className="text-sm text-gray-300">
              URL de la API
            </Label>
            <Input
              id="apiUrl"
              type="text"
              value={localApiUrl}
              onChange={(e) => setLocalApiUrl(e.target.value)}
              placeholder="http://tu-api.com/chat"
              className="bg-[#1a1a1a] border-white/10 text-[#ececec] placeholder-gray-500"
            />
          </div>

          {/* Auth Header */}
          <div className="space-y-2">
            <Label htmlFor="authHeader" className="text-sm text-gray-300">
              Header de Autenticación
            </Label>
            <Input
              id="authHeader"
              type="text"
              value={localAuthHeader}
              onChange={(e) => setLocalAuthHeader(e.target.value)}
              placeholder="X-API-Key"
              className="bg-[#1a1a1a] border-white/10 text-[#ececec] placeholder-gray-500"
            />
            <p className="text-xs text-gray-500">
              Nombre del header para enviar la API key (ej: X-API-Key, Authorization). Usa &quot;Bearer&quot; para formato Authorization: Bearer token.
            </p>
          </div>
        </div>

        <div className="flex justify-end pt-2">
          <Button
            onClick={handleSave}
            className="bg-[#10a37f] hover:bg-[#0d8c6d] text-white rounded-lg px-6"
          >
            <Save className="w-4 h-4 mr-2" />
            Guardar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
