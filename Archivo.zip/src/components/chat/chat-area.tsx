'use client';

import { useEffect, useRef } from 'react';
import { useChatStore } from '@/lib/store';
import MessageBubble from './message-bubble';
import { Sparkles, Code, Lightbulb, BookOpen, Loader2 } from 'lucide-react';

const suggestions = [
  {
    icon: <Code className="w-5 h-5" />,
    title: 'Explícame un concepto',
    description: 'de programación',
  },
  {
    icon: <Lightbulb className="w-5 h-5" />,
    title: 'Ayúdame a escribir',
    description: 'un correo profesional',
  },
  {
    icon: <BookOpen className="w-5 h-5" />,
    title: 'Resúmeme este artículo',
    description: 'o documento',
  },
  {
    icon: <Sparkles className="w-5 h-5" />,
    title: 'Dame ideas creativas',
    description: 'para un proyecto',
  },
];

interface ChatAreaProps {
  onSendMessage: (message: string) => void;
}

export default function ChatArea({ onSendMessage }: ChatAreaProps) {
  const { conversations, currentConversationId, isStreaming } = useChatStore();
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const currentConversation = conversations.find((c) => c.id === currentConversationId);
  const messages = currentConversation?.messages || [];

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, messages.length > 0 ? messages[messages.length - 1]?.content : null]);

  const hasMessages = messages.length > 0;
  const lastMessage = messages[messages.length - 1];
  const isLoading = isStreaming && lastMessage?.content === '...';

  if (!hasMessages && !isStreaming) {
    return (
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="text-center max-w-2xl mx-auto">
          <div className="w-16 h-16 mx-auto mb-6 rounded-full bg-[#10a37f]/10 flex items-center justify-center">
            <Sparkles className="w-8 h-8 text-[#10a37f]" />
          </div>
          <h1 className="text-2xl md:text-3xl font-semibold text-[#ececec] mb-8">
            ¿Cómo puedo ayudarte hoy?
          </h1>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg mx-auto">
            {suggestions.map((suggestion, index) => (
              <button
                key={index}
                onClick={() => onSendMessage(`${suggestion.title} ${suggestion.description}`)}
                className="flex items-center gap-3 p-3 rounded-xl border border-white/10 hover:bg-white/5 transition-colors text-left group"
              >
                <div className="text-[#10a37f] group-hover:scale-110 transition-transform">
                  {suggestion.icon}
                </div>
                <div>
                  <div className="text-sm font-medium text-[#ececec]">{suggestion.title}</div>
                  <div className="text-xs text-gray-400">{suggestion.description}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto">
      <div className="max-w-3xl mx-auto px-4 py-6">
        {messages.map((message, index) => {
          const isLast = index === messages.length - 1;
          return (
            <MessageBubble
              key={message.id}
              message={message}
              isLoading={isLast && isLoading && message.role === 'assistant'}
            />
          );
        })}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
}
