'use client';

import { useMemo } from 'react';
import { useChatStore, Conversation } from '@/lib/store';
import { Plus, MessageSquare, Trash2, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { cn } from '@/lib/utils';

interface SidebarProps {
  onNewChat: () => void;
  onOpenSettings: () => void;
  className?: string;
}

function groupConversations(conversations: Conversation[]) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today.getTime() - 86400000);
  const sevenDaysAgo = new Date(today.getTime() - 7 * 86400000);
  const thirtyDaysAgo = new Date(today.getTime() - 30 * 86400000);

  const groups: { label: string; items: Conversation[] }[] = [
    { label: 'Hoy', items: [] },
    { label: 'Ayer', items: [] },
    { label: 'Últimos 7 días', items: [] },
    { label: 'Últimos 30 días', items: [] },
    { label: 'Anteriores', items: [] },
  ];

  for (const conv of conversations) {
    const convDate = new Date(conv.updatedAt);
    if (convDate >= today) {
      groups[0].items.push(conv);
    } else if (convDate >= yesterday) {
      groups[1].items.push(conv);
    } else if (convDate >= sevenDaysAgo) {
      groups[2].items.push(conv);
    } else if (convDate >= thirtyDaysAgo) {
      groups[3].items.push(conv);
    } else {
      groups[4].items.push(conv);
    }
  }

  return groups.filter((g) => g.items.length > 0);
}

export default function Sidebar({ onNewChat, onOpenSettings, className }: SidebarProps) {
  const {
    conversations,
    currentConversationId,
    setCurrentConversation,
    deleteConversation,
  } = useChatStore();

  const grouped = useMemo(() => groupConversations(conversations), [conversations]);

  return (
    <div className={cn('flex flex-col h-full bg-[#171717]', className)}>
      {/* New Chat Button */}
      <div className="p-3">
        <Button
          onClick={onNewChat}
          variant="ghost"
          className="w-full justify-start gap-3 text-[#ececec] hover:bg-white/10 rounded-xl px-3 h-11"
        >
          <Plus className="w-5 h-5" />
          <span className="text-sm">Nuevo chat</span>
        </Button>
      </div>

      <Separator className="bg-white/10" />

      {/* Conversation List */}
      <ScrollArea className="flex-1 px-2 py-2">
        <div className="space-y-4">
          {grouped.map((group) => (
            <div key={group.label}>
              <h3 className="px-3 py-1 text-xs font-medium text-gray-500">{group.label}</h3>
              <div className="space-y-0.5">
                {group.items.map((conv) => (
                  <div
                    key={conv.id}
                    className={cn(
                      'group flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer transition-colors text-sm',
                      currentConversationId === conv.id
                        ? 'bg-white/10 text-white'
                        : 'text-gray-300 hover:bg-white/5'
                    )}
                    onClick={() => setCurrentConversation(conv.id)}
                  >
                    <MessageSquare className="w-4 h-4 flex-shrink-0 opacity-60" />
                    <span className="truncate flex-1">{conv.title}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteConversation(conv.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-white/10 transition-opacity"
                      title="Eliminar chat"
                    >
                      <Trash2 className="w-3.5 h-3.5 text-gray-400 hover:text-red-400" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {conversations.length === 0 && (
            <div className="px-3 py-8 text-center text-sm text-gray-500">
              No hay conversaciones
            </div>
          )}
        </div>
      </ScrollArea>

      <Separator className="bg-white/10" />

      {/* Settings Button */}
      <div className="p-2">
        <Button
          onClick={onOpenSettings}
          variant="ghost"
          className="w-full justify-start gap-3 text-gray-300 hover:bg-white/10 rounded-lg px-3 h-10"
        >
          <Settings className="w-4 h-4" />
          <span className="text-sm">Ajustes</span>
        </Button>
      </div>
    </div>
  );
}
