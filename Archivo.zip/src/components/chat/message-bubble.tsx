'use client';

import { Message } from '@/lib/store';
import { Bot, Loader2 } from 'lucide-react';
import MarkdownRenderer from './markdown-renderer';

interface MessageBubbleProps {
  message: Message;
  isLoading?: boolean;
}

export default function MessageBubble({ message, isLoading }: MessageBubbleProps) {
  const isUser = message.role === 'user';

  if (isUser) {
    return (
      <div className="flex justify-end mb-6">
        <div className="max-w-[85%] md:max-w-[70%]">
          <div className="bg-[#2f2f2f] rounded-2xl rounded-br-md px-4 py-3">
            <p className="text-[15px] leading-relaxed whitespace-pre-wrap text-[#ececec]">
              {message.content}
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Loading state
  if (isLoading) {
    return (
      <div className="flex justify-start mb-6">
        <div className="flex gap-3 max-w-full md:max-w-[85%]">
          <div className="flex-shrink-0 w-7 h-7 rounded-full bg-[#10a37f] flex items-center justify-center mt-0.5">
            <Bot className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 py-2 text-gray-400 text-sm">
              <Loader2 className="w-4 h-4 animate-spin text-[#10a37f]" />
              <span>Pensando...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-start mb-6">
      <div className="flex gap-3 max-w-full md:max-w-[85%]">
        <div className="flex-shrink-0 w-7 h-7 rounded-full bg-[#10a37f] flex items-center justify-center mt-0.5">
          <Bot className="w-4 h-4 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          {message.content && message.content !== '...' ? (
            <div className="text-[#ececec]">
              <MarkdownRenderer content={message.content} />
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
